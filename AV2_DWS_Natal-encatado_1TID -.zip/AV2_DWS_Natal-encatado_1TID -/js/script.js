
/*  1. MENU PARA CELULARES*/


// Busca o botão que abre e fecha o menu
const botaoMenu = document.getElementById("botao-menu");

// Busca a área que contém os links do menu
const menu = document.getElementById("menu");

// Verifica se esses elementos existem nesta página
if (botaoMenu && menu) {

    // Executa esta função quando o botão for clicado
    botaoMenu.addEventListener("click", function () {

        // Adiciona ou remove a classe que mostra o menu
        const menuAberto = menu.classList.toggle("aberto");

        // Atualiza a informação de acessibilidade do botão
        botaoMenu.setAttribute("aria-expanded", menuAberto);

        // Troca o símbolo conforme o menu está aberto ou fechado
        botaoMenu.textContent = menuAberto ? "×" : "☰";
    });

    // Fecha o menu depois que o usuário escolhe uma página
    menu.querySelectorAll("a").forEach(function (link) {

        link.addEventListener("click", function () {

            menu.classList.remove("aberto");

            botaoMenu.setAttribute("aria-expanded", "false");

            botaoMenu.textContent = "☰";
        });
    });
}

// 2. PRODUTOS EM DESTAQUE

// Seleciona o espaço onde os produtos serão mostrados
const areaDestaques = document.getElementById("produtos-destaque");

// Lista inicial de produtos da loja
const produtosDestaque = [
    {
        nome: "Árvore de Natal",
        categoria: "Decoração",
        descricao: "Uma árvore para decorar sua casa.",
        preco: 189.90,
        imagem: "img/arvore-produto.png"
    },
    {
        nome: "Presente Especial",
        categoria: "Presentes",
        descricao: "Um presente para surpreender alguém.",
        preco: 79.90,
        imagem: "img/presente.png" 
    },
    {
        nome: "Enfeites Natalinos",
        categoria: "Enfeites",
        descricao: "Pequenos detalhes cheios de encanto.",
        preco: 39.90,
        imagem: "img/decoracoes.png"
    }
    

];

// Formata um número como preço em reais
function formatarPreco(valor) {

    return valor.toLocaleString("pt-BR", {
        style: "currency",
        currency: "BRL"
    });
}

// Cria os cartões dos produtos na página
function mostrarDestaques() {

    // Se a página não tiver a área de produtos, encerra a função
    if (!areaDestaques) {
        return;
    }

    // Limpa o espaço antes de inserir os cartões
    areaDestaques.innerHTML = "";

    // Percorre cada produto da lista
    produtosDestaque.forEach(function (produto) {

        // Cria um cartão para o produto
        const cartao = document.createElement("article");

        cartao.className = "cartao-produto";

        // Cria a imagem do produto
        const imagem = document.createElement("img");

        imagem.className = "imagem-produto";
        imagem.src = produto.imagem;
        imagem.alt = produto.nome;
        imagem.loading = "lazy";

        // Cria a área das informações
        const informacoes = document.createElement("div");

        informacoes.className = "info-produto";

        // Insere categoria, nome, descrição e preço
        informacoes.innerHTML = `
            <span class="categoria-produto">${produto.categoria}</span>
            <h3>${produto.nome}</h3>
            <p class="descricao-produto">${produto.descricao}</p>
            <span class="preco-produto">${formatarPreco(produto.preco)}</span>
            <a class="botao-adicionar" href="produtos.html">
                Ver produto
            </a>
        `;

        // Junta a imagem e as informações no cartão
        cartao.appendChild(imagem);
        cartao.appendChild(informacoes);

        // Adiciona o cartão na grade da página
        areaDestaques.appendChild(cartao);
    });
}

// Executa a função para mostrar os produtos
mostrarDestaques();

/* =========================================
   3. AMPLIAR IMAGENS DA GALERIA
   ========================================= */

// Procura todas as imagens que estão na galeria.
const imagensGaleria = document.querySelectorAll(".grade-galeria img");

// Adiciona um evento de clique em cada imagem.
imagensGaleria.forEach(function (imagem) {

    imagem.addEventListener("click", function () {

        // Cria a camada escura da visualização.
        const lightbox = document.createElement("div");
        lightbox.className = "lightbox";

        // Cria uma cópia da imagem escolhida.
        const imagemAmpliada = document.createElement("img");
        imagemAmpliada.src = imagem.src;
        imagemAmpliada.alt = imagem.alt;

        // Cria o botão de fechar.
        const botaoFechar = document.createElement("button");
        botaoFechar.textContent = "×";
        botaoFechar.setAttribute("aria-label", "Fechar imagem");

        // Fecha a visualização quando o botão for clicado.
        botaoFechar.addEventListener("click", function () {
            lightbox.remove();
        });

        // Também fecha quando o fundo escuro for clicado.
        lightbox.addEventListener("click", function (evento) {
            if (evento.target === lightbox) {
                lightbox.remove();
            }
        });

        // Fecha a visualização ao pressionar Escape.
        function fecharComEscape(evento) {
            if (evento.key === "Escape") {
                lightbox.remove();
                document.removeEventListener("keydown", fecharComEscape);
            }
        }

        document.addEventListener("keydown", fecharComEscape);

        // Junta os elementos e mostra a camada.
        lightbox.append(imagemAmpliada, botaoFechar);
        document.body.appendChild(lightbox);
    });
});

/* =========================================
   4. FORMULÁRIO DE CONTATO
   ========================================= */

// Procura o formulário e o espaço para a resposta.
const formularioContato = document.getElementById("form-contato");
const retornoContato = document.getElementById("retorno-contato");

// Só configura o formulário se ele existir na página atual.
if (formularioContato && retornoContato) {

    formularioContato.addEventListener("submit", function (evento) {

        // Impede o navegador de recarregar a página.
        evento.preventDefault();

        // Lê o nome informado pelo visitante.
        const nomeVisitante = document.getElementById("nome").value.trim();

        // Mostra uma mensagem de confirmação demonstrativa.
        retornoContato.textContent =
            "Obrigado pela mensagem, " + nomeVisitante +
            "! O formulário foi preenchido corretamente.";

        // Limpa os campos depois da confirmação.
        formularioContato.reset();
    });
}

